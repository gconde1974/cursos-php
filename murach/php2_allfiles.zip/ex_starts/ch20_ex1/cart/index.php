<?php  include '../util/main.php'; ?>
<?php include '../view/header.php'; ?>
<div id="content">
    <h2>Shopping Cart - under construction</h2>
</div>
<?php include '../view/footer.php'; ?>
